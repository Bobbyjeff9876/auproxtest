export interface JoinOptions {
    /**
     * Whether or not to actually spawn the player.
     */
    doSpawn?: boolean;
}
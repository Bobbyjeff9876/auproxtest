export interface VersionInfo {
    year: number;
    month: number;
    day: number;
    build: number;
}